import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class noiseClockColor extends PApplet {

float centerH = 0;
float widthH = 0.7f;


float minB = 0.3f;
float maxB = 1.0f;
float alpha = 0.04f;
float transStart = 0.35f;
float transWidth = 0.01f;
float transStart2 = 0.45f;
float transWidth2 = 0.01f;

float radTransStart = 0.18f;
float radTransWidth = 0.15f;

float ah = 0.02f;
float ab = 0.055f;
float af = 0.014f;
float ag = 1;

float th = 0.060f;
float tb = 0.010f;
float tf = 0.005f;
float tc = 0.003f;
float tA = 0.4f;

int numSpokes = 12;
float ang;
int w = 1;

float[] px;
float[] py;
float[] pf;
int[] pa;

int[] P;

float cr = 4;
float hourWidth = 0.013f;
float hourLength = 0.2f;
float minuteWidth = 0.013f;
float minuteLength = 0.25f;
float secondWidth = 0.01f;
float secondLength = 0.57f;
float backEnd = 0.04f;

int startTime;
int startSeconds;

float xRes;
float yRes;
public void setup() {
  
  xRes = PApplet.parseFloat(width);
  yRes = PApplet.parseFloat(height);
  centerH = random(0, 1);
  noStroke();
  background(0);
  ang = 2*PI/PApplet.parseFloat(numSpokes);

  startTime = millis();
  startSeconds = second();
  println(startSeconds);

  P = new int[(width/2)*(height/2)];
  for ( int x = 0; x < width/2; x++ ) {
    for ( int y = 0; y < height/2; y++ ) {
      P[x+y*width/2] = color(0, 0, 0);
    }
  }

  px = new float[(width/2)*(height/2)];
  py = new float[(width/2)*(height/2)];
  pf = new float[(width/2)*(height/2)];
  pa = new int[(width/2)*(height/2)];
  for ( int x = 0; x < width/2; x++ ) {
    for ( int y = 0; y < height/2; y++ ) {
      float x2 = PApplet.parseFloat(x) + 0.5f;
      float y2 = PApplet.parseFloat(y) + 0.5f;
      PVector v = new PVector( x2, y2 );
      float a = (v.heading() + PI)%ang;
      if ( a > 0.5f*ang ) { 
        a = ang - a;
      }
      float r = v.mag();
      px[x+y*width/2] = r*cos(a);
      py[x+y*width/2] = r*sin(a);
      if ( r < radTransStart*yRes ) {
        pf[x+y*width/2] = 0;
      } else if  (r >= (radTransStart)*yRes && r < (radTransStart+radTransWidth)*yRes ) {
        pf[x+y*width/2] = (r-(radTransStart*yRes))/(radTransWidth*yRes);
      } else {
        pf[x+y*width/2] = 1;
      }
      pa[x+y*width/2] = 0;
    }
  }
}

public void draw() {
  float t = tA*PApplet.parseFloat(frameCount);
  loadPixels();
  float transEnd = transStart + transWidth;
  float transEnd2 = transStart2 + transWidth2;
  for ( int x = 0; x < width/2; x++ ) {
    for ( int y = 0; y<=x && y<height/2; y++ ) {
      float x2 = px[x+y*width/2];
      float y2 = py[x+y*width/2];

      float f = noise( ag*af*(30*xRes + x2), ag*af*(30*yRes + y2), tf*t ) * pf[x+y*width/2] ;
      int c;
      if ( f > transStart && f < transEnd || f > transStart2 && f < transEnd2 ) {
        c = lerpColor( P[x+y*width/2], color(255, 255, 255), alpha );
        pa[x+y*width/2] = 0;
      } else if ( f >= transStart+transWidth && f < transStart2 ) {
        float h = (frameCount*tc*tA + centerH + widthH*(-0.5f+noise( ag*ah*(0*xRes + x2), ag*ah*y2, th*t ) ) )%1;
        float b = lerp( minB, maxB, (f-transEnd)/(1-transEnd));
        c = lerpColor( P[x+y*width/2], hsbColor(h*360, 1, b), alpha );
        pa[x+y*width/2] = 0;
      } else {
        if ( pa[x+y*width/2] < 20 ) {
          c = lerpColor( P[x+y*width/2], color(0, 0, 0), alpha );
          pa[x+y*width/2]++;
        } else { 
          c = color( 0, 0, 0 );
        }
      }
      P[x+y*width/2] = c;
      pixels[ (width/2+x) + (height/2+y)*width ] = c;
      pixels[ (width/2+x) + (height/2-y)*width ] = c;
      pixels[ (width/2-x) + (height/2+y)*width ] = c;
      pixels[ (width/2-x) + (height/2-y)*width ] = c;
      if ( x < height/2 ) {
        pixels[ (width/2+y) + (height/2+x)*width ] = c;
        pixels[ (width/2+y) + (height/2-x)*width ] = c;
        pixels[ (width/2-y) + (height/2+x)*width ] = c;
        pixels[ (width/2-y) + (height/2-x)*width ] = c;
      }
    }
  }
  updatePixels();

  // clock stuff
  float secAng = TWO_PI * PApplet.parseFloat(second())/60;
  float minAng = TWO_PI * (PApplet.parseFloat(minute())+PApplet.parseFloat(second())/60)/60;
  float hourAng = TWO_PI * (PApplet.parseFloat(hour()%12)+PApplet.parseFloat(minute())/60)/12;
  translate( 0.5f*xRes, 0.5f*yRes );
  stroke( 255, 255, 255, 128 );
  fill(0);
  float h = (frameCount*tc*tA + centerH + widthH*(-0.5f+noise( 0.1f*th*t ) ) )%1;
  int c = hsbColor( h*360, 0.5f, 0.5f) ;
  
  strokeWeight(1.0f);
  float cr = 4;
  fill( red(c), green(c), blue(c), 196 );
  
  pushMatrix();
  rotate( PI+minAng );
  rect( -0.5f*minuteWidth*yRes, -backEnd*yRes, minuteWidth*yRes, minuteLength*yRes, cr, cr, cr, cr );
  popMatrix();
  h = (frameCount*tc*tA + centerH + widthH*(-0.5f+noise( -0.1f*th*t ) ) )%1;
  c = hsbColor( h*360, 0.5f, 0.5f) ;
  fill( red(c), green(c), blue(c), 196 );
  pushMatrix();
  rotate( PI+hourAng );
  rect( -0.5f*hourWidth*yRes, -backEnd*yRes, hourWidth*yRes, hourLength*yRes, cr, cr, cr, cr );
  popMatrix();
  noStroke();


  if ( frameCount%50 == 0 ) {
    println(frameRate);
  }
}

public void mouseClicked() { 
  exit();
}

public void mouseMoved() {
}
public void mouseDragged() {
}

public int hsbColor( float h, float s, float b ) {
  float c = b*s;
  float x = c*( 1 - abs( (h/60) % 2 - 1 ) );
  float m = b - c;
  float rp = 0;
  float gp = 0;
  float bp = 0;
  if ( 0 <= h && h < 60 ) {
    rp = c;  
    gp = x;  
    bp = 0;
  }
  if ( 60 <= h && h < 120 ) {
    rp = x;  
    gp = c;  
    bp = 0;
  }
  if ( 120 <= h && h < 180 ) {
    rp = 0;  
    gp = c;  
    bp = x;
  }
  if ( 180 <= h && h < 240 ) {
    rp = 0;  
    gp = x;  
    bp = c;
  }
  if ( 240 <= h && h < 300 ) {
    rp = x;  
    gp = 0;  
    bp = c;
  }
  if ( 300 <= h && h < 360 ) {
    rp = c;  
    gp = 0;  
    bp = x;
  }
  return color( (rp+m)*255, (gp+m)*255, (bp+m)*255 );
}
  public void settings() {  size( 800, 480 ); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--hide-stop", "noiseClockColor" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
